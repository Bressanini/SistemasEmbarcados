#!/bin/sh
# This script is empty, it simply needs to exist to make the
# nfs-config.service happy.
