Run the emulation with:

 qemu-system-or1k -kernel output/images/vmlinux -nographic

The login prompt will appear in the terminal that started Qemu.

Ethernet support is not working, yet.

Tested with QEMU 2.9.0.
